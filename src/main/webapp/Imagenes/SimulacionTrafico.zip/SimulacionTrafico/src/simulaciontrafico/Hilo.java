/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simulaciontrafico;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Estudiante
 */
public class Hilo extends Thread{
    
    private boolean estado;
    PanelSimulador panelSimulador;
    public int tiempo;
    
    public Hilo(PanelSimulador panelSimulador) {
        setName("Trafico");
        estado = true;
        this.panelSimulador = panelSimulador;
        tiempo = 0;
    }

    @Override
    public void run() {
        while(true) {
            try {
                if (estado) {
                    tiempo ++;
                    if(tiempo%5 == 0) {
                        panelSimulador.agregarCarro();
                    }
                    panelSimulador.cambiarSemaforo(tiempo);
                    panelSimulador.recorrerCarro();
                    panelSimulador.repaint();
                }
                Thread.sleep(500);
            } catch (InterruptedException ex) {
                Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public PanelSimulador getPanelSimulador() {
        return panelSimulador;
    }

    public void setPanelSimulador(PanelSimulador panelSimulador) {
        this.panelSimulador = panelSimulador;
    }

    public int getTiempo() {
        return tiempo;
    }

    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }
    
    
}
