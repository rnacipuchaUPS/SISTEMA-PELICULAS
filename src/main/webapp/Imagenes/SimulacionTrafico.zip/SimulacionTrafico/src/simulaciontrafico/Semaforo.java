/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simulaciontrafico;

/**
 *
 * @author Estudiante
 */
public class Semaforo {
    private int x;
    private int y;
    public int ancho = 50;
    public int alto = 80;
    private int estado;

    public Semaforo(int x, int y) {
        this.x = x;
        this.y = y;
        estado = 1;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }
    
    
    
    
}
